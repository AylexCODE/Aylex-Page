package Main;

public class Main {

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
        login.setResizable(false);
        login.setLocationRelativeTo(null);
    }
}
