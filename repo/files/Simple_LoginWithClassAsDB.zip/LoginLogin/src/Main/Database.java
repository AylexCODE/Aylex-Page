package Main;

public class Database {
    String fname;
    String lname;
    String contactNo;
    String sex;
    String username;
    String passwd;
    
    public Database(String fname, String lname, String contactNo, String sex, String username, String passwd){
        this.fname = fname;
        this.lname = lname;
        this.contactNo = contactNo;
        this.sex = sex;
        this.username = username;
        this.passwd = passwd;
    }
    
    public String getFName(){
        return fname;
    }
    
    public String getLName(){
        return lname;
    }
    
    public String getContactNo(){
        return contactNo;
    }
    
    public String getSex(){
        return sex;
    }
    
    public String getUsername(){
        return username;
    }
    
    public String getPasswd(){
        return passwd;
    }
}
